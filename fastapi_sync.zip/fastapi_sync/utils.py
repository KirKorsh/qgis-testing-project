import json
from qgis.core import QgsGeometry, QgsPointXY, QgsWkbTypes


def qgis_geometry_from_geojson(geometry_dict):
    #Конвертация GeoJSON в QgsGeometry
    try:
        if not geometry_dict or "type" not in geometry_dict:
            return QgsGeometry()
        
        geom_type = geometry_dict["type"]
        
        if geom_type == "Point":
            coords = geometry_dict["coordinates"]
            if len(coords) >= 2:
                return QgsGeometry.fromPointXY(QgsPointXY(coords[0], coords[1]))
        
        elif geom_type == "LineString":
            coords = geometry_dict["coordinates"]
            if coords and len(coords) > 0:
                points = [QgsPointXY(x, y) for x, y in coords]
                return QgsGeometry.fromPolylineXY(points)
        
        elif geom_type == "Polygon":
            coords = geometry_dict["coordinates"]
            if coords and len(coords) > 0:
                # Берем первое кольцо (внешний контур)
                ring = coords[0]
                if ring and len(ring) > 0:
                    points = [QgsPointXY(x, y) for x, y in ring]
                    return QgsGeometry.fromPolygonXY([points])
        
        return QgsGeometry()
        
    except Exception as e:
        print(f"Ошибка конвертации геометрии: {e}")
        return QgsGeometry()


def geometry_to_payload(qgs_geometry, geom_type):
    # Конвертация QgsGeometry в формат для отправки на сервер
    try:
        if geom_type == "Point":
            point = qgs_geometry.asPoint()
            geom_data = {
                "type": "Point",
                "coordinates": [point.x(), point.y()]
            }
        
        elif geom_type == "LineString":
            points = qgs_geometry.asPolyline()
            geom_data = {
                "type": "LineString",
                "coordinates": [[point.x(), point.y()] for point in points]
            }
        
        elif geom_type == "Polygon":
            polygons = qgs_geometry.asPolygon()
            if polygons and len(polygons) > 0:
                
                ring = polygons[0]
                geom_data = {
                    "type": "Polygon",
                    "coordinates": [[[point.x(), point.y()] for point in ring]]
                }
            else:
                geom_data = {
                    "type": "Polygon",
                    "coordinates": []
                }
        
        else:
            geom_data = {
                "type": "GeometryCollection",
                "geometries": []
            }
        
        return {
            "geom": geom_data,
            "geom_type": geom_type
        }
        
    except Exception as e:
        print(f"Ошибка подготовки геометрии: {e}")
        return {
            "geom": {
                "type": geom_type,
                "coordinates": []
            },
            "geom_type": geom_type
        }