import json
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsField,
    QgsGeometry, QgsPointXY, QgsWkbTypes,
    QgsCoordinateReferenceSystem, QgsMessageLog, Qgis
)
from qgis.PyQt.QtCore import QVariant, pyqtSignal, QObject, QTimer
from qgis.PyQt.QtGui import QColor
import traceback

from .api_client import get_features, create_feature, delete_feature
from .utils import qgis_geometry_from_geojson, geometry_to_payload

class FastAPISyncService(QObject):
    
    sync_finished = pyqtSignal(bool, str) # Сигнал для уведомления UI
    
    def __init__(self):
        super().__init__()
        self.project = QgsProject.instance()
        self.sync_in_progress = False
        
        # Слои для синхронизации
        self.sync_layers = {}
        
        # Очередь для отложенных удалений (server_id)
        self.pending_deletions = []
        
        # Таймер для отложенной отправки удалений
        self.deletion_timer = QTimer()
        self.deletion_timer.setSingleShot(True)
        self.deletion_timer.timeout.connect(self.process_pending_deletions)
        
        # Карта: QGIS feature_id -> server_id для корректного удаления
        self.feature_id_to_server_id = {}
        
        # Подписка на глобальные события проекта
        self.project.layersWillBeRemoved.connect(self.on_layers_will_be_removed)
        
        QgsMessageLog.logMessage("Сервис синхронизации инициализирован", "FastAPI Sync", Qgis.Info)

    def ensure_layers(self):
        # Создание/получение слоёв для синхронизации
        try:
            layer_defs = [
                ("Points_synced", "Point", QgsWkbTypes.Point, QColor("red")),
                ("Lines_synced", "LineString", QgsWkbTypes.LineString, QColor("blue")),
                ("Polygons_synced", "Polygon", QgsWkbTypes.Polygon, QColor(0, 255, 0, 100))
            ]
            
            for name, geom_type, qgis_type, color in layer_defs:
                layer = self._get_or_create_layer(name, geom_type, qgis_type, color)
                if layer:
                    self.sync_layers[name] = layer
                    self._setup_layer_signals(layer)
            
            return self.sync_layers
            
        except Exception as e:
            QgsMessageLog.logMessage(f"Ошибка создания слоёв: {e}", "FastAPI Sync", Qgis.Critical)
            raise

    def _get_or_create_layer(self, name, geom_type, qgis_type, color):
        #Создание слоя в памяти с нужными полями
        existing = self.project.mapLayersByName(name)
        if existing:
            return existing[0]
        
        uri = f"{geom_type}?crs=EPSG:4326&field=id:integer&field=server_id:integer&field=geom_type:string(50)&field=status:string(20)"
        layer = QgsVectorLayer(uri, name, "memory")
        
        if not layer.isValid():
            QgsMessageLog.logMessage(f"Слой {name} невалиден", "FastAPI Sync", Qgis.Warning)
            return None
        
        # Настройка отображения
        layer.renderer().symbol().setColor(color)
        if geom_type == "Point":
            layer.renderer().symbol().setSize(3)
        elif geom_type == "LineString":
            layer.renderer().symbol().setWidth(2)
        
        self.project.addMapLayer(layer)
        QgsMessageLog.logMessage(f"Создан слой: {name}", "FastAPI Sync", Qgis.Info)
        
        return layer

    def _setup_layer_signals(self, layer):
        # Отписка от старых соединений
        try:
            layer.committedFeaturesAdded.disconnect()
            layer.committedFeaturesRemoved.disconnect()
            layer.beforeRollBack.disconnect()
            layer.editingStarted.disconnect()
            layer.editingStopped.disconnect()
        except:
            pass  # Если не было подключений - игнорируем
        
        # Подключение с использованием слабых ссылок
        layer.committedFeaturesAdded.connect(
            lambda layer_id, features: self.on_committed_features_added(layer_id, features)
        )
        layer.committedFeaturesRemoved.connect(
            lambda layer_id, feature_ids: self.on_committed_features_removed(layer_id, feature_ids)
        )
        layer.beforeRollBack.connect(
            lambda: self.on_before_rollback(layer)
        )
        layer.editingStarted.connect(
            lambda: self.on_editing_started(layer)
        )
        layer.editingStopped.connect(
            lambda: self.on_editing_stopped(layer)
        )

    def on_layers_will_be_removed(self, layer_ids):
        # Очиcка ресурсов при удалении слоёв из проекта
        for layer_id in layer_ids:
            layer = self.project.mapLayer(layer_id)
            if layer and layer.name() in self.sync_layers:
                # Очищаем кэш для этого слоя
                keys_to_remove = [k for k, v in self.feature_id_to_server_id.items() 
                                 if v.layer_id == layer_id]
                for key in keys_to_remove:
                    del self.feature_id_to_server_id[key]


    # МЕТОДЫ СИНХРОНИЗАЦИИ 
    def perform_full_sync(self):

        # Выполняет полную синхронизацию
        if self.sync_in_progress:
            self.sync_finished.emit(False, "Синхронизация уже выполняется")
            return
            
        self.sync_in_progress = True
        QgsMessageLog.logMessage("Начало полной синхронизации", "FastAPI Sync", Qgis.Info)
        
        try:
            #  Отправка локальных изменений на сервер
            self.sync_local_changes_to_server()
            
            #  Загружаем всех данные с сервера 
            self.load_from_server()
            
            #  Обновляем кэш соответствий
            self.update_feature_id_mapping()
            
            self.sync_finished.emit(True, "Синхронизация завершена")
            
        except Exception as e:
            error_msg = f"Ошибка синхронизации: {str(e)}"
            QgsMessageLog.logMessage(error_msg, "FastAPI Sync", Qgis.Critical)
            self.sync_finished.emit(False, error_msg)
            
        finally:
            self.sync_in_progress = False

    def sync_local_changes_to_server(self):
        # Отправка новых объектов на сервер
        QgsMessageLog.logMessage("Отправка локальных изменений на сервер", "FastAPI Sync", Qgis.Info)
        
        sent_count = 0
        for layer_name, layer in self.sync_layers.items():
            if "Points" in layer_name:
                geom_type = "Point"
            elif "Lines" in layer_name:
                geom_type = "LineString"
            elif "Polygons" in layer_name:
                geom_type = "Polygon"
            else:
                continue
            
            # Поиск объектов со статусом "new"
            for feature in layer.getFeatures():
                if feature["status"] == "new":
                    try:
                        payload = geometry_to_payload(feature.geometry(), geom_type)
                        response = create_feature(payload)
                        
                        if response and "id" in response:
                            # Обновка объектов в слое
                            layer.startEditing()
                            feature.setAttribute("server_id", response["id"])
                            feature.setAttribute("status", "synced")
                            layer.updateFeature(feature)
                            layer.commitChanges()
                            
                            # Обновление кэша
                            self.feature_id_to_server_id[feature.id()] = {
                                "server_id": response["id"],
                                "layer_id": layer.id()
                            }
                            
                            sent_count += 1
                            QgsMessageLog.logMessage(
                                f"Объект отправлен на сервер, ID: {response['id']}", 
                                "FastAPI Sync", Qgis.Info
                            )
                            
                    except Exception as e:
                        QgsMessageLog.logMessage(
                            f"Ошибка отправки объекта: {e}", 
                            "FastAPI Sync", Qgis.Warning
                        )
        
        if sent_count > 0:
            QgsMessageLog.logMessage(f"Отправлено объектов: {sent_count}", "FastAPI Sync", Qgis.Info)

    def load_from_server(self):
        # Загрузка всех объектов с сервера, заменяя локальные
        QgsMessageLog.logMessage("Загрузка данных с сервера", "FastAPI Sync", Qgis.Info)
        
        try:
            data = get_features()
            if "features" not in data:
                QgsMessageLog.logMessage("Нет данных для загрузки", "FastAPI Sync", Qgis.Info)
                return
            
            # Временно отключаем обработку событий
            self.sync_in_progress = True
            
            # Очистка слоёв
            for layer in self.sync_layers.values():
                provider = layer.dataProvider()
                provider.truncate()
                layer.updateExtents()
            
            # Заполнение слоёв новыми данными
            loaded_count = 0
            for feature_data in data["features"]:
                geom_type = feature_data["properties"]["geom_type"]
                server_id = feature_data.get("id")
                
                layer_name = f"{geom_type}s_synced"
                layer = self.sync_layers.get(layer_name)
                
                if layer and "geometry" in feature_data:
                    qgs_feature = QgsFeature(layer.fields())
                    qgs_feature.setAttribute("id", loaded_count)
                    qgs_feature.setAttribute("server_id", server_id)
                    qgs_feature.setAttribute("geom_type", geom_type)
                    qgs_feature.setAttribute("status", "synced")
                    
                    geometry = qgis_geometry_from_geojson(feature_data["geometry"])
                    if not geometry.isNull():
                        qgs_feature.setGeometry(geometry)
                        provider = layer.dataProvider()
                        provider.addFeature(qgs_feature)
                        
                        # Запоминание соответствий
                        self.feature_id_to_server_id[qgs_feature.id()] = {
                            "server_id": server_id,
                            "layer_id": layer.id()
                        }
                        
                        loaded_count += 1
            
            # Обновление слоёв
            for layer in self.sync_layers.values():
                layer.updateExtents()
                layer.triggerRepaint()
            
            QgsMessageLog.logMessage(f"Загружено объектов: {loaded_count}", "FastAPI Sync", Qgis.Info)
            
        except Exception as e:
            QgsMessageLog.logMessage(f"Ошибка загрузки: {e}", "FastAPI Sync", Qgis.Critical)
            raise
        finally:
            self.sync_in_progress = False


    def on_committed_features_added(self, layer_id, features):
        # Немедленная проверка не в процессе ли уже синхронизации или обновления
        if self.sync_in_progress:
            return

        layer = self.project.mapLayer(layer_id)
        if not layer or layer.name() not in self.sync_layers:
            return

        # Определение типа геометрии по имени слоя
        geom_type = None
        if "Points" in layer.name():
            geom_type = "Point"
        elif "Lines" in layer.name():
            geom_type = "LineString"
        elif "Polygons" in layer.name():
            geom_type = "Polygon"

        if not geom_type:
            return

        # Обрабатка каждого добавленного объекта
        for feature in features:
            # Получаем текущий server_id и статус объекта
            current_server_id = feature["server_id"]
            current_status = feature["status"]

            # Отправляем на сервер только новые объекты без server_id
            if not current_server_id and current_status != "synced":
                try:
                    # Подготовка и отправление данных на сервер
                    payload = geometry_to_payload(feature.geometry(), geom_type)
                    response = create_feature(payload)

                    if response and "id" in response:
                        #  Отключение сигналов слоя перед его обновлением
                        layer.blockSignals(True) 
                        
                        # Обновление объект в слое
                        layer.startEditing()
                        # Устанавливка полученного server_id и финальный статус
                        feature.setAttribute("server_id", response["id"])
                        feature.setAttribute("geom_type", geom_type)
                        feature.setAttribute("status", "synced")
                        layer.updateFeature(feature)
                        layer.commitChanges()
                        
                        # Восстанавление сигналов
                        layer.blockSignals(False)  

                        # Обновление внутренного кэша плагина
                        self.feature_id_to_server_id[feature.id()] = {
                            "server_id": response["id"],
                            "layer_id": layer.id()
                        }

                        QgsMessageLog.logMessage(
                            f"Объект создан и синхронизирован. Server ID: {response['id']}",
                            "FastAPI Sync",
                            Qgis.Info
                        )
                    else:
                        # Если сервер не вернул ID, помечаем как new для повторной попытки
                        self._mark_feature_as_new(layer, feature, geom_type)
                        
                except Exception as e:
                    QgsMessageLog.logMessage(
                        f"Ошибка при автоматической отправке объекта: {e}",
                        "FastAPI Sync",
                        Qgis.Critical
                    )
                    # При ошибке помечаем как new
                    self._mark_feature_as_new(layer, feature, geom_type)
            else:
                # Если у объекта уже есть server_id просто логируем
                QgsMessageLog.logMessage(
                    f"Объект уже синхронизирован (Server ID: {current_server_id})",
                    "FastAPI Sync",
                    Qgis.Info
                )

    def _mark_feature_as_new(self, layer, feature, geom_type): # помечает объект как 'new', не вызывая рекурсии
        try:
            layer.blockSignals(True)  # Временно отключаем сигналы
            layer.startEditing()
            feature.setAttribute("geom_type", geom_type)
            feature.setAttribute("status", "new")
            layer.updateFeature(feature)
            layer.commitChanges()
        except Exception as e:
            QgsMessageLog.logMessage(
                f"Не удалось пометить объект как 'new': {e}",
                "FastAPI Sync",
                Qgis.Warning
            )
        finally:
            layer.blockSignals(False)

    def on_committed_features_removed(self, layer_id, feature_ids):
        # Обработчик удаления объектов после сохранения 
        if self.sync_in_progress:
            return
            
        layer = self.project.mapLayer(layer_id)
        if not layer or layer.name() not in self.sync_layers:
            return
        
        # Получение server_id из кэша перед удалением
        for fid in feature_ids:
            if fid in self.feature_id_to_server_id:
                server_id = self.feature_id_to_server_id[fid]["server_id"]
                # Добавление в очередь для удаления на сервере
                self.pending_deletions.append(server_id)
                
                # Удаление из кэша
                del self.feature_id_to_server_id[fid]
        
        # Запуск таймера для отправки удалений
        if self.pending_deletions:
            self.deletion_timer.start(1000)
        
        QgsMessageLog.logMessage(
            f"Удалены объекты из слоя {layer.name()}, в очереди на удаление: {len(self.pending_deletions)}", 
            "FastAPI Sync", Qgis.Info
        )

    def process_pending_deletions(self):
        # Отправление накопленных запросов на удаление на сервер
        if not self.pending_deletions or self.sync_in_progress:
            return
        
        success_count = 0
        failed_ids = []
        
        for server_id in self.pending_deletions[:]:  # Копирование списока для итерации
            try:
                if delete_feature(server_id):
                    success_count += 1
                    self.pending_deletions.remove(server_id)
                else:
                    failed_ids.append(server_id)
            except Exception as e:
                QgsMessageLog.logMessage(
                    f"Ошибка удаления объекта {server_id}: {e}", 
                    "FastAPI Sync", Qgis.Warning
                )
                failed_ids.append(server_id)
        
        if success_count > 0:
            QgsMessageLog.logMessage(
                f"Удалено объектов на сервере: {success_count}", 
                "FastAPI Sync", Qgis.Info
            )
        
        if failed_ids:
            QgsMessageLog.logMessage(
                f"Не удалось удалить объекты: {failed_ids}", 
                "FastAPI Sync", Qgis.Warning
            )

    def update_feature_id_mapping(self):
        # Обновление кэша соответствий QGIS feature_id -> server_id
        self.feature_id_to_server_id.clear()
        
        for layer in self.sync_layers.values():
            for feature in layer.getFeatures():
                server_id = feature["server_id"]
                if server_id:
                    self.feature_id_to_server_id[feature.id()] = {
                        "server_id": server_id,
                        "layer_id": layer.id()
                    }


    # ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ

    def on_editing_started(self, layer):
        if self.sync_in_progress:
            return
        QgsMessageLog.logMessage(f"Начато редактирование слоя {layer.name()}", "FastAPI Sync", Qgis.Info)

    def on_editing_stopped(self, layer):
        if self.sync_in_progress:
            return
        QgsMessageLog.logMessage(f"Завершено редактирование слоя {layer.name()}", "FastAPI Sync", Qgis.Info)

    def on_before_rollback(self, layer):
        # Очистка кэша при откате изменений
        if self.sync_in_progress:
            return
        
        # Нахождение и удаление временных записец для этого слоя
        keys_to_remove = []
        for key, value in self.feature_id_to_server_id.items():
            if value["layer_id"] == layer.id():
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self.feature_id_to_server_id[key]
        
        QgsMessageLog.logMessage(f"Откат изменений в слое {layer.name()}", "FastAPI Sync", Qgis.Info)

    def cleanup(self):
        # Корректная очистка ресурсов при завершении работы плагина
        QgsMessageLog.logMessage("Очистка ресурсов плагина", "FastAPI Sync", Qgis.Info)
        
        # Отписка от всех сигналов
        for layer in self.sync_layers.values():
            try:
                layer.committedFeaturesAdded.disconnect()
                layer.committedFeaturesRemoved.disconnect()
                layer.beforeRollBack.disconnect()
                layer.editingStarted.disconnect()
                layer.editingStopped.disconnect()
            except:
                pass
        
        # Останавка таймера
        if self.deletion_timer.isActive():
            self.deletion_timer.stop()
        
        # Отправка оставшихся удаления
        if self.pending_deletions:
            self.process_pending_deletions()
        
        # Очистка структуры данных
        self.sync_layers.clear()
        self.feature_id_to_server_id.clear()
        self.pending_deletions.clear()