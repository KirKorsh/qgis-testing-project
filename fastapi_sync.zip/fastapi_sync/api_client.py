import requests
import json
from qgis.core import QgsMessageLog, Qgis
import traceback

API_URL = "http://localhost:8000"


def log_message(message, level=Qgis.Info):     # Логирование сообщений.

    QgsMessageLog.logMessage(message, "FastAPI Sync", level)


def get_features():     # Получение  объектов с сервера
    
    try:
        log_message("Отправка запроса к /features...", Qgis.Info)
        response = requests.get(f"{API_URL}/features", timeout=30)
        response.raise_for_status()
        data = response.json()
        log_message(f"Получено {len(data.get('features', []))} объектов", Qgis.Info)
        return data
    except requests.exceptions.ConnectionError as e:
        error_msg = f"Не удалось подключиться к серверу {API_URL}. Проверьте, запущен ли FastAPI сервер."
        log_message(error_msg, Qgis.Critical)
        log_message(f"Детали: {str(e)}", Qgis.Critical)
        raise Exception(error_msg)
    except requests.exceptions.Timeout:
        error_msg = "Таймаут при подключении к сервера."
        log_message(error_msg, Qgis.Warning)
        raise Exception(error_msg)
    except Exception as e:
        error_msg = f"Ошибка при получении объектов: {str(e)}"
        log_message(error_msg, Qgis.Critical)
        log_message(traceback.format_exc(), Qgis.Critical)
        raise Exception(error_msg)


def create_feature(payload):
    try:
        log_message(f"Отправка POST запроса к /features с данными: {json.dumps(payload)[:100]}...", Qgis.Info)
        response = requests.post(
            f"{API_URL}/features",
            json=payload,
            timeout=10,
            headers={"Content-Type": "application/json"}
        )
        response.raise_for_status()
        result = response.json()
        log_message(f"Объект создан, ID: {result.get('id')}", Qgis.Info)
        return result
    except requests.exceptions.RequestException as e:
        error_msg = f"Ошибка при создании объекта: {str(e)}"
        log_message(error_msg, Qgis.Critical)
        raise Exception(error_msg)
    except Exception as e:
        error_msg = f"Неизвестная ошибка: {str(e)}"
        log_message(error_msg, Qgis.Critical)
        log_message(traceback.format_exc(), Qgis.Critical)
        raise Exception(error_msg)


def delete_feature(feature_id):     # Удаляет объект с сервера

    try:
        log_message(f"Отправка DELETE запроса для объекта ID: {feature_id}", Qgis.Info)
        response = requests.delete(f"{API_URL}/features/{feature_id}", timeout=10)
        response.raise_for_status()
        log_message(f"Объект {feature_id} удален с сервера", Qgis.Info)
        return True
    except requests.exceptions.RequestException as e:
        log_message(f"Ошибка при удалении объекта: {str(e)}", Qgis.Warning)
        return False
    except Exception as e:
        log_message(f"Неизвестная ошибка при удалении: {str(e)}", Qgis.Warning)
        return False


def get_stats():    # Получает статистику с сервера - для будущего использования.
    
    try:
        log_message("Запрос статистики с сервера...", Qgis.Info)
        response = requests.get(f"{API_URL}/stats", timeout=10)
        response.raise_for_status()
        stats = response.json()
        log_message(f"Статистика: {stats}", Qgis.Info)
        return stats
    except Exception as e:
        log_message(f"Ошибка при получении статистики: {str(e)}", Qgis.Warning)
        return {"points": 0, "linestrings": 0, "polygons": 0}