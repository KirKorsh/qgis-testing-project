from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QProgressDialog
from qgis.core import QgsProject, QgsMessageLog, Qgis

from .sync import FastAPISyncService
from .resources import *
import os.path


class FastAPISync:

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'FastAPISync_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        self.actions = []
        self.menu = self.tr(u'&FastAPI Sync')
        self.first_start = None
        self.service = None

    def unload(self):   # Выгрузка плагина

        if self.service:
            self.service.cleanup()
            self.service = None

    def tr(self, message):
        
        return QCoreApplication.translate('FastAPI_Sync', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if add_to_toolbar:
            self.iface.addToolBarIcon(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        
        icon_path = ':/plugins/FastAPI_Sync/icon.png'
        
        # Кнопка для полной синхронизации 
        self.sync_action = self.add_action(
            icon_path,
            text=self.tr('Синхронизировать с сервером'),
            callback=self.run_full_sync,
            parent=self.iface.mainWindow(),
            status_tip=self.tr('Полная синхронизация в обе стороны: отправка изменений и загрузка данных')
        )

        self.first_start = True

    def unload(self):
        
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&FastAPI Sync'), action)
            self.iface.removeToolBarIcon(action)

    def run_full_sync(self):
        try:
            # Создание сервиса если еще не создан
            if not self.service:
                self.service = FastAPISyncService()
            
            # Диалог прогресса
            progress = QProgressDialog(
                "Синхронизация с сервером...", 
                "Отмена", 
                0, 
                100, 
                self.iface.mainWindow()
            )
            progress.setWindowModality(Qt.WindowModal)
            progress.setValue(10)
            
            # Создание слои если их нет
            progress.setLabelText("Проверка и создание слоев...")
            self.service.ensure_layers()
            progress.setValue(30)
            
            # Выполнение синхронизации (отправка + загрузка)
            progress.setLabelText("Выполнение полной синхронизации...")
            self.service.perform_full_sync()  
            progress.setValue(80)
            
            # Обновление карты
            progress.setLabelText("Обновление карты...")
            self.iface.mapCanvas().refreshAllLayers()
            progress.setValue(100)
            
            # Показываем сообщение об успехе
            self.iface.messageBar().pushMessage(
                "Успех",
                "Полная синхронизация завершена! Данные отправлены и загружены.",
                level=Qgis.Success,
                duration=5
            )
            
        except Exception as e:
            error_msg = f"Ошибка синхронизации: {str(e)}"
            QgsMessageLog.logMessage(error_msg, "FastAPI Sync", Qgis.Critical)
            self.iface.messageBar().pushMessage(
                "Ошибка",
                error_msg,
                level=Qgis.Critical,
                duration=10
            )